import time
import math
import pycom
import crypto
from ADXL345 import ADXL345
from ADXL3452 import ADXL3452
from machine import I2C
from nvs import Nvs

def Random():
   r = crypto.getrandbits(32)
   return ((r[0]<<24)+(r[1]<<16)+(r[2]<<8)+r[3])/4294967295.0

pycom.heartbeat(False)
b=[0.0181,0.0543,0.0543,0.0181]
a=[1.000,-1.7600,1.1829,-0.2781]
n=0;
fx=[]
x=[]
fy=[]
y=[]
filtX=0;
for j in range(4):
    fx.append(0)
for j in range(4):
    x.append(0)
for j in range(4):
    fy.append(0)
for j in range(4):
    y.append(0)

with open('datafile.csv', 'w') as datafile:
    datafile.write("Hello!\n")
    for i in range(0,3):
        datafile.write(str(i)+','+str(i*i)+'\n')
    datafile.close()
print('Datafile written.')
filtX=0;
filtY=0;
count_X=0;
count_Y=0;
#with open('datafile.csv') as datafile:
#    print(datafile.read())
#datafile.close()
#print('Datafile read.') 
# Send data continuously to Pybytes
while True:
    for i in range(0,20):
        i2c = I2C(0, I2C.MASTER, baudrate=100000)
        scans = i2c.scan() # returns list of slave addresses
        #print(scans)
        obj = ADXL345(i2c)
        #print(obj.xValue, obj.yValue, obj.zValue,)
        adxl3452 = ADXL3452()
    	axes = adxl3452.getAxes(True)
    	xacce=axes['x']
        yacce=axes['y']
        #r= Random()
        print(str(yacce)+','+str(filtX)+','+str(filtY))
        if n>3:
            filtX=(b[0]*xacce)+(b[1]*fx[0])+(b[2]*fx[1])+(b[3]*fx[2])-(a[1]*x[0])-(a[2]*x[1])-(a[3]*x[2])
            fx[3]=fx[2]
            fx[2]=fx[1]
            fx[1]=fx[0]
            fx[0]=xacce
            x[3]=x[2]
            x[2]=x[1]
            x[1]=x[0]
            x[0]=filtX
            filtY=(b[0]*yacce)+(b[1]*fy[0])+(b[2]*fy[1])+(b[3]*fy[2])-(a[1]*y[0])-(a[2]*y[1])-(a[3]*y[2])
            fy[3]=fy[2]
            fy[2]=fy[1]
            fy[1]=fy[0]
            fy[0]=yacce
            y[3]=y[2]
            y[2]=y[1]
            y[1]=y[0]
            y[0]=filtY
            pybytes.send_signal(1, xacce) #send raw X acceleration
            pybytes.send_signal(2, filtX) ##send filtered X acceleration
            pybytes.send_signal(3, yacce) #send raw Y acceleration
            pybytes.send_signal(4, filtY) ##send filtered Y acceleration
        if abs(filtX)>0.3 and abs(filtY)>0.3 :
            pycom.rgbled(0x0000EB)
            count_X=count_X+1;
            count_Y=count_Y+1;
        elif abs(filtX)>0.3:
            pycom.rgbled(0x6d6149)
            count_X=count_X+1;
        elif abs(filtY)>0.3 :
            pycom.rgbled(0xFF0000)
            count_Y=count_Y+1;
        else:
            pycom.rgbled(0x00FF00)
        if n%30==0:
            pybytes.send_signal(5, count_Y) #send raw Y acceleration
            pybytes.send_signal(6, count_X) ##send filtered Y acceleration
            count_Y=0;
            count_X=0;
            #print('sent signal {}'.format(filtX))
        time.sleep(.1)
        n=n+1
